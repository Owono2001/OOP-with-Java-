/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaassignmentReal;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;


/**
 *
 * @author user
 */
public class FileOperations {
    
    public void saveCarsList(Car CObject){        
        try {
            File file = new File("carlist.txt");
            FileWriter fw = new FileWriter(file,true);
            BufferedWriter bw = new BufferedWriter(fw);            
            bw.write(CObject.CarDetails());
            bw.close();
            fw.close();
        }catch (IOException ex) {}
    }
    
    public void appendNewBooking(Booking newBookingObj){
       try {
            File file = new File("rentalStatusList.txt");
            FileWriter fw = new FileWriter(file,true);
            BufferedWriter bw = new BufferedWriter(fw);            
            bw.write(newBookingObj.BookingDetails());
            bw.close();
            fw.close();
        }catch (IOException ex) {} 
    }
    
    public void appendReport(Report reportBookingObj){
        try {
            File file = new File("report.txt");
            FileWriter fw = new FileWriter(file,true);
            BufferedWriter bw = new BufferedWriter(fw);            
            bw.write(reportBookingObj.BookingDetails());
            bw.close();
            fw.close();
        }catch (IOException ex) {} 
    }
    
    public void saveCustomersList(Customer customerObj){
        try {
            File file = new File("customerAccount.txt");
            FileWriter fw = new FileWriter(file,true);
            BufferedWriter bw = new BufferedWriter(fw);            
            bw.write(customerObj.CustomerDetails());
            bw.close();
            fw.close();
        }catch (IOException ex) {} 
    }
    
        public static void AdminRegister(AdministrationRegistrationClass obj) {
        
        
        try {
            FileWriter adminfw = new FileWriter("adminAccount.txt",true);
            BufferedWriter bw = new BufferedWriter(adminfw);
            bw.write(obj.AdminDetails());
            bw.newLine();
            bw.close();
            adminfw.close();
            JOptionPane.showMessageDialog(null, "Registered successfully");

        }catch (Exception Ex) {
            JOptionPane.showMessageDialog(null, "Error" + Ex);
        }
    }
    public static void CustomerRegister(CustomerRegistrationClass obj1){
        
        try{
            FileWriter customerfw = new FileWriter("customerAccount.txt",true);
            BufferedWriter bw = new BufferedWriter(customerfw);
            bw.write(obj1.CustomerDetails());
            bw.newLine();
            bw.close();
            customerfw.close();
            JOptionPane.showMessageDialog(null, "Registered successfully");
        }catch(Exception E){
            JOptionPane.showMessageDialog(null, "Error" + E);
        }
   
    }
}

