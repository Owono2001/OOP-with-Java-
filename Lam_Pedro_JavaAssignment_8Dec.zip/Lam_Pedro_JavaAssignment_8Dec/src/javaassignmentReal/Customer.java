/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaassignmentReal;

/**
 *
 * @author user
 */
public class Customer {
    private String Username;
    private String Password;
    private String Email;
    private String ContactNo;
    
    public Customer(){
    }
    
    /*public void setCustomerUsername(String username){
        Username = username;
    }
    public void setPassword(String password){
        Password = password;
    }
    public void setContactNo(String contactNo){
        ContactNo = contactNo;
    }
    public void setEmail(String email){
        Email = email;
    }
    
    public String getCustomerUsername(){
        return Username;
    }
    public String getPassword(){
        return Password;
    }
    public String getEmail(){
        return Email;
    }
    public String getContactNo(){
        return ContactNo;
    }*/
    
    public Customer(String _username, String _password, String _contactNo, String _email){
        Username = _username;
        Password = _password;
        ContactNo = _contactNo;
        Email = _email;
    }
    
    public String CustomerDetails(){
        return Username +","+ Password +","+ ContactNo +","+ Email +"\n";
    }
}
