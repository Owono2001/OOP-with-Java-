/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaassignmentReal;

/**
 *
 * @author user
 */
public class Booking {
    protected String CustomerUsername;
    protected String CarModelName;
    protected String CarRegistrationNo;
    protected String PickUpDate;
    protected String Duration;
    protected String TotalCost;
    private String RentalStatus;
    protected String BookingStatus;
    
    public Booking(){
    }
    
    public Booking(String username, String CModelName, String CRegistrationNo, String PickupDate, String rentDuration, String total_cost, String rental_status){
        CustomerUsername = username;
        CarModelName = CModelName;
        CarRegistrationNo = CRegistrationNo;
        PickUpDate = PickupDate;
        Duration = rentDuration;
        TotalCost = total_cost;
        RentalStatus = rental_status;
    }
  
    
    public String BookingDetails(){
        return CustomerUsername +","+ CarModelName +","+ CarRegistrationNo +","+ PickUpDate +","+ Duration +","+ TotalCost +","+ RentalStatus +"\n";
    }
}