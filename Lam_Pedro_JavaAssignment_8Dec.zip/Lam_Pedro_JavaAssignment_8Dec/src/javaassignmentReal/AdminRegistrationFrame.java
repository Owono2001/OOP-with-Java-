package javaassignmentReal;


import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
/**
 *
 * @author PEDRO
 */
public class AdminRegistrationFrame extends javax.swing.JFrame {

    //private AdministrationRegistrationClass AdministrationRegistrationClass;
    //private FileOperatons myfileOp;

    public AdminRegistrationFrame() {
        initComponents();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelAdminUsername = new javax.swing.JLabel();
        jLabelAdminTitle = new javax.swing.JLabel();
        txtAdminPassword = new javax.swing.JPasswordField();
        jLabelAdminPassword = new javax.swing.JLabel();
        jLabelAdminContactNumber = new javax.swing.JLabel();
        txtAdminUsername = new javax.swing.JTextField();
        jLabelAdminEmail = new javax.swing.JLabel();
        txtAdminContactNumber = new javax.swing.JTextField();
        txtAdminEmail = new javax.swing.JTextField();
        jButtonAdminRegister = new javax.swing.JButton();
        jLabelAdminConfirmPassword = new javax.swing.JLabel();
        txtAdminConfirmPassword = new javax.swing.JPasswordField();
        jButtonAdminClear = new javax.swing.JButton();
        backToLoginPageButton = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Create Admin Account");

        jLabelAdminUsername.setText("Username:");

        jLabelAdminTitle.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabelAdminTitle.setText("CREATE NEW ADMIN ACCOUNT");

        jLabelAdminPassword.setText("Password:");

        jLabelAdminContactNumber.setText("Contact Number:");

        jLabelAdminEmail.setText("Email:");

        jButtonAdminRegister.setText("REGISTER");
        jButtonAdminRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAdminRegisterActionPerformed(evt);
            }
        });

        jLabelAdminConfirmPassword.setText("Confirm Password:");

        jButtonAdminClear.setText("CLEAR");
        jButtonAdminClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAdminClearActionPerformed(evt);
            }
        });

        backToLoginPageButton.setText("BACK TO LOGIN PAGE");
        backToLoginPageButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backToLoginPageButtonMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelAdminTitle)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelAdminConfirmPassword)
                            .addComponent(jLabelAdminPassword)
                            .addComponent(jLabelAdminUsername)
                            .addComponent(jLabelAdminContactNumber)
                            .addComponent(jLabelAdminEmail)
                            .addComponent(jButtonAdminRegister))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtAdminUsername)
                                .addComponent(txtAdminPassword)
                                .addComponent(txtAdminContactNumber)
                                .addComponent(txtAdminConfirmPassword)
                                .addComponent(txtAdminEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jButtonAdminClear))))
                .addContainerGap(26, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(backToLoginPageButton)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(backToLoginPageButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabelAdminTitle)
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelAdminUsername)
                    .addComponent(txtAdminUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelAdminPassword)
                    .addComponent(txtAdminPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelAdminConfirmPassword)
                    .addComponent(txtAdminConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelAdminContactNumber)
                    .addComponent(txtAdminContactNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelAdminEmail)
                    .addComponent(txtAdminEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonAdminRegister)
                    .addComponent(jButtonAdminClear))
                .addContainerGap(43, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(495, 370));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonAdminRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAdminRegisterActionPerformed

        if (txtAdminUsername.getText().isEmpty() || txtAdminPassword.getText().isEmpty() || txtAdminConfirmPassword.getText().isEmpty() || txtAdminContactNumber.getText().isEmpty() || txtAdminEmail.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "one/more fields is/are empty");
        } else {

            if (txtAdminPassword.getText().equals(txtAdminConfirmPassword.getText())) {
                AdministrationRegistrationClass object = new AdministrationRegistrationClass(txtAdminUsername.getText(), txtAdminPassword.getText(), txtAdminConfirmPassword.getText(), txtAdminContactNumber.getText(), txtAdminEmail.getText());
                FileOperations.AdminRegister(object);
                
                txtAdminConfirmPassword.setText("");
                txtAdminContactNumber.setText("");
                txtAdminEmail.setText("");
                txtAdminPassword.setText("");
                txtAdminUsername.setText("");
               
                LoginAdmin loginadmin = new LoginAdmin();
                loginadmin.setVisible(true);
                loginadmin.pack();
                loginadmin.setLocationRelativeTo(null);
                loginadmin.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
                this.dispose();

            } else {
                JOptionPane.showMessageDialog(null, "Password don't match. Please use same password for confirm password");

            }
        }


    }//GEN-LAST:event_jButtonAdminRegisterActionPerformed

    private void jButtonAdminClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAdminClearActionPerformed

        if (txtAdminUsername.getText().isEmpty() || txtAdminPassword.getText().isEmpty() || txtAdminConfirmPassword.getText().isEmpty() || txtAdminContactNumber.getText().isEmpty() || txtAdminEmail.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "fields are already empty");
        } else {
            txtAdminUsername.setText(null);
            txtAdminPassword.setText(null);
            txtAdminConfirmPassword.setText(null);
            txtAdminContactNumber.setText(null);
            txtAdminEmail.setText(null);
        }

    }//GEN-LAST:event_jButtonAdminClearActionPerformed

    private void backToLoginPageButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backToLoginPageButtonMouseClicked
        LoginPage_1 L = new LoginPage_1();
        L.setVisible(true);
        L.pack();
        L.setLocationRelativeTo(null);
        L.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_backToLoginPageButtonMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminRegistrationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminRegistrationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminRegistrationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminRegistrationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminRegistrationFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel backToLoginPageButton;
    private javax.swing.JButton jButtonAdminClear;
    private javax.swing.JButton jButtonAdminRegister;
    private javax.swing.JLabel jLabelAdminConfirmPassword;
    private javax.swing.JLabel jLabelAdminContactNumber;
    private javax.swing.JLabel jLabelAdminEmail;
    private javax.swing.JLabel jLabelAdminPassword;
    private javax.swing.JLabel jLabelAdminTitle;
    private javax.swing.JLabel jLabelAdminUsername;
    private javax.swing.JPasswordField txtAdminConfirmPassword;
    private javax.swing.JTextField txtAdminContactNumber;
    private javax.swing.JTextField txtAdminEmail;
    private javax.swing.JPasswordField txtAdminPassword;
    private javax.swing.JTextField txtAdminUsername;
    // End of variables declaration//GEN-END:variables
}
