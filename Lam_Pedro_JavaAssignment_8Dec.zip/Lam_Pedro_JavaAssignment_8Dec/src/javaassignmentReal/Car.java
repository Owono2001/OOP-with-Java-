/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaassignmentReal;

/**
 *
 * @author user
 */
public class Car {
    private String CarModelName;
    private String CarRegistrationNo;
    private String CostPerDay;
    
    public Car(){
    }
      
    public Car(String CModelName, String CRegistrationNo, String CPerDay){
        CarModelName = CModelName;
        CarRegistrationNo = CRegistrationNo;
        CostPerDay = CPerDay;
    }
    
    public String CarDetails(){
        return CarModelName +","+ CarRegistrationNo +","+ CostPerDay +"\n";
    }
    
}
