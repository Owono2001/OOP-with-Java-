package javaassignmentReal;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author PEDRO
 */
public class CustomerRegistrationClass {
    private String Username;
    private String Password;
    private String ConfirmPassword;
    private String ContactNumber;
    private String Email;

    public CustomerRegistrationClass(String Usernamec, String Passwordc, String ConfirmPasswordc, String ContactNumberc, String Emailc) {
        Username = Usernamec;
        Password = Passwordc;
        ConfirmPassword = ConfirmPasswordc;
        ContactNumber = ContactNumberc;
        Email = Emailc;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getConfirmPassword() {
        return ConfirmPassword;
    }

    public void setConfirmPassword(String ConfirmPassword) {
        this.ConfirmPassword = ConfirmPassword;
    }

    public String getContactNumber() {
        return ContactNumber;
    }

    public void setContactNumber(String ContactNumber) {
        this.ContactNumber = ContactNumber;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }
    public String CustomerDetails(){
        return Username + "," + Password + "," + ContactNumber + "," + Email;
    }
    
    
}
