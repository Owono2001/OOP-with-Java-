/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaassignmentReal;

/**
 *
 * @author user
 */
public class Report extends Booking {

    
    public Report(String username, String CModelName, String CRegistrationNo, String PickupDate, String rentDuration, String booking_status, String total_cost){
        CustomerUsername = username;
        CarModelName = CModelName;
        CarRegistrationNo = CRegistrationNo;
        PickUpDate = PickupDate;
        Duration = rentDuration;
        BookingStatus = booking_status;
        TotalCost = total_cost;
    }
    
    public String BookingDetails(){
        return CustomerUsername +","+ CarModelName +","+ CarRegistrationNo +","+ PickUpDate +","+ Duration +","+ BookingStatus +","+ TotalCost +"\n";
    }
}
